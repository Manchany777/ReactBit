import React from 'react';

const NotFiles = () => {
    return (
        <div  className='page'>
            <h1>NotFiles Page</h1>
        </div>
    );
};

export default NotFiles;