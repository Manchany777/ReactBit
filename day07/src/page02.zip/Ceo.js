import React from 'react';

const Ceo = () => {
    return (
        <div className='page'>
            <h1>Ceo Page</h1>
        </div>
    );
};

export default Ceo;